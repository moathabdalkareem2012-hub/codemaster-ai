package com.codemasterai.app

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.content.Context
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.io.OutputStreamWriter
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("codemaster_settings", MODE_PRIVATE) }
    private val executor = Executors.newSingleThreadExecutor()
    private val history = JSONArray()
    private lateinit var transcript: LinearLayout
    private lateinit var input: EditText
    private lateinit var send: Button
    private lateinit var status: TextView
    private val bg = Color.rgb(9, 13, 24)
    private val panel = Color.rgb(17, 26, 42)
    private val cyan = Color.rgb(100, 216, 245)
    private val white = Color.rgb(237, 243, 255)
    private val muted = Color.rgb(141, 155, 178)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        addBubble("CodeMaster AI", "مرحباً! أنا مساعدك البرمجي. أدخل إعدادات مزود الذكاء الاصطناعي من زر الإعدادات، ثم اكتب ما تريد بناءه أو إصلاحه.", false)
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            setPadding(dp(14), dp(12), dp(14), dp(10))
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val title = TextView(this).apply {
            text = "⌘  CodeMaster AI"
            textSize = 21f
            setTypeface(null, Typeface.BOLD)
            setTextColor(white)
        }
        val settings = Button(this).apply {
            text = "الإعدادات"
            setTextColor(white)
            setBackgroundColor(Color.rgb(38, 52, 72))
            setOnClickListener { showSettings() }
        }
        header.addView(title, LinearLayout.LayoutParams(0, dp(50), 1f))
        header.addView(settings)
        root.addView(header)

        status = TextView(this).apply {
            text = "مساعد برمجي · API"
            textSize = 12f
            setTextColor(cyan)
            setPadding(0, dp(5), 0, dp(10))
        }
        root.addView(status)

        val scroll = ScrollView(this)
        transcript = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(2), dp(4), dp(2), dp(12))
        }
        scroll.addView(transcript)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        input = EditText(this).apply {
            hint = "اكتب طلبك البرمجي هنا..."
            setHintTextColor(muted)
            setTextColor(white)
            textSize = 15f
            setPadding(dp(13), dp(12), dp(13), dp(12))
            setBackgroundColor(panel)
            minLines = 2
            maxLines = 5
        }
        root.addView(input, LinearLayout.LayoutParams(-1, -2))

        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(8), 0, 0)
        }
        send = Button(this).apply {
            text = "إرسال  ↑"
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.rgb(45, 125, 160))
            setOnClickListener { sendMessage() }
        }
        val hint = TextView(this).apply {
            text = "راجع الأكواد واختبرها قبل استخدامها"
            textSize = 10f
            setTextColor(muted)
        }
        bottom.addView(hint, LinearLayout.LayoutParams(0, dp(48), 1f))
        bottom.addView(send)
        root.addView(bottom)
        setContentView(root)
    }

    private fun addBubble(who: String, text: String, isUser: Boolean) {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(9), dp(12), dp(9))
            setBackgroundColor(if (isUser) Color.rgb(35, 31, 61) else panel)
        }
        val label = TextView(this).apply {
            this.text = who
            textSize = 11f
            setTextColor(cyan)
            setTypeface(null, Typeface.BOLD)
        }
        val body = TextView(this).apply {
            this.text = text
            textSize = 14f
            setTextColor(white)
            setPadding(0, dp(5), 0, 0)
        }
        card.addView(label)
        card.addView(body)
        val lp = LinearLayout.LayoutParams(-1, -2)
        lp.bottomMargin = dp(10)
        transcript.addView(card, lp)
    }

    private fun sendMessage() {
        val prompt = input.text.toString().trim()
        if (prompt.isEmpty()) return
        val key = prefs.getString("api_key", "") ?: ""
        if (key.isBlank()) {
            Toast.makeText(this, "أدخل مفتاح API من الإعدادات أولاً", Toast.LENGTH_LONG).show()
            showSettings()
            return
        }
        addBubble("أنت", prompt, true)
        history.put(JSONObject().put("role", "user").put("content", prompt))
        input.setText("")
        send.isEnabled = false
        status.text = "جارٍ التفكير..."
        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(input.windowToken, 0)

        executor.execute {
            try {
                val base = (prefs.getString("base_url", "https://api.openai.com/v1") ?: "").trim().trimEnd('/')
                val model = prefs.getString("model", "gpt-4.1-mini") ?: "gpt-4.1-mini"
                val msgs = JSONArray()
                msgs.put(JSONObject().put("role", "system").put("content",
                    "أنت CodeMaster AI، مساعد برمجي عملي. أجب بالعربية عند استخدام العربية. ساعد في بناء المشاريع وكتابة الأكواد وتصحيحها وشرحها. كن صريحاً بشأن ما لم تختبره. لا تدّع تنفيذ شيء لم تنفذه. لا تساعد في البرمجيات الخبيثة أو الاختراق غير المصرح به، وقدّم بديلاً آمناً."))
                val start = maxOf(0, history.length() - 16)
                for (i in start until history.length()) msgs.put(history.getJSONObject(i))
                val payload = JSONObject()
                    .put("model", model)
                    .put("messages", msgs)
                    .put("temperature", 0.3)
                    .put("max_tokens", 3000)

                val conn = (URL("$base/chat/completions").openConnection() as HttpURLConnection)
                conn.requestMethod = "POST"
                conn.connectTimeout = 20000
                conn.readTimeout = 60000
                conn.doOutput = true
                conn.setRequestProperty("Authorization", "Bearer $key")
                conn.setRequestProperty("Content-Type", "application/json")
                OutputStreamWriter(conn.outputStream, Charsets.UTF_8).use { it.write(payload.toString()) }
                val code = conn.responseCode
                val stream = if (code in 200..299) conn.inputStream else conn.errorStream
                val response = stream.bufferedReader().use { it.readText() }
                conn.disconnect()
                val json = JSONObject(response)
                if (code !in 200..299) throw Exception(json.optJSONObject("error")?.optString("message") ?: "HTTP $code")
                val answer = json.getJSONArray("choices").getJSONObject(0)
                    .getJSONObject("message").getString("content")
                history.put(JSONObject().put("role", "assistant").put("content", answer))
                runOnUiThread {
                    addBubble("CodeMaster AI", answer, false)
                    status.text = "متصل · $model"
                    send.isEnabled = true
                }
            } catch (e: Exception) {
                runOnUiThread {
                    addBubble("خطأ", "تعذر إكمال الطلب: ${e.message}\nتحقق من الإنترنت وإعدادات API.", false)
                    status.text = "تعذر الاتصال"
                    send.isEnabled = true
                }
            }
        }
    }

    private fun showSettings() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(8), dp(18), 0)
        }
        fun field(hintText: String, value: String, secret: Boolean = false): EditText {
            return EditText(this).apply {
                hint = hintText
                setSingleLine(true)
                setText(value)
                if (secret) inputType = 0x00000081
            }
        }
        val base = field("API Base URL", prefs.getString("base_url", "https://api.openai.com/v1") ?: "")
        val model = field("Model", prefs.getString("model", "gpt-4.1-mini") ?: "")
        val key = field("API Key", prefs.getString("api_key", "") ?: "", true)
        box.addView(TextView(this).apply { text = "رابط API الأساسي"; setTextColor(white) })
        box.addView(base)
        box.addView(TextView(this).apply { text = "اسم النموذج"; setTextColor(white) })
        box.addView(model)
        box.addView(TextView(this).apply { text = "مفتاح API"; setTextColor(white) })
        box.addView(key)
        AlertDialogCompat.show(this, box) {
            prefs.edit().putString("base_url", base.text.toString().trim())
                .putString("model", model.text.toString().trim())
                .putString("api_key", key.text.toString().trim()).apply()
            status.text = "تم حفظ الإعدادات محلياً"
        }
    }

    override fun onDestroy() {
        executor.shutdown()
        super.onDestroy()
    }
}

private object AlertDialogCompat {
    fun show(activity: Activity, view: View, onSave: () -> Unit) {
        android.app.AlertDialog.Builder(activity)
            .setTitle("إعدادات الذكاء الاصطناعي")
            .setMessage("استخدم بيانات مزود API متوافق مع OpenAI Chat Completions.")
            .setView(view)
            .setNegativeButton("إلغاء", null)
            .setPositiveButton("حفظ") { _, _ -> onSave() }
            .show()
    }
}
