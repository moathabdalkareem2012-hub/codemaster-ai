plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.codemasterai.app"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.codemasterai.app"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.0"
    }
}
