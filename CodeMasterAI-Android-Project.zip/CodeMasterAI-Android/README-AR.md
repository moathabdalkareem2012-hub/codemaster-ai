# CodeMaster AI لنظام Android

هذا مشروع Android Studio جاهز للبناء. يتضمن واجهة عربية داكنة ومحادثة مع API متوافق مع OpenAI Chat Completions.

## بناء APK
- افتح المشروع في Android Studio حديث.
- انتظر مزامنة Gradle.
- اختر Build > Build Bundle(s) / APK(s) > Build APK(s).
- ملف APK التجريبي يظهر عادة في `app/build/outputs/apk/debug/app-debug.apk`.

## البناء من GitHub دون كمبيوتر
1. أنشئ مستودعاً جديداً على GitHub.
2. ارفع محتويات هذا المجلد إلى المستودع.
3. افتح تبويب Actions وشغّل `Build CodeMaster AI APK`.
4. بعد نجاح البناء افتح تشغيل Workflow ونزّل Artifact باسم `CodeMasterAI-debug-apk`.
5. فك ضغط Artifact وثبّت `app-debug.apk` على هاتف Android.

## الاستخدام
افتح التطبيق > الإعدادات، ثم أدخل:
- API Base URL: `https://api.openai.com/v1`
- Model: نموذج متاح في حساب مزودك، مثل `gpt-4.1-mini`
- API Key: مفتاحك الخاص

## تنبيه أمني
هذا إصدار شخصي أولي؛ مفتاح API يُحفظ محلياً في SharedPreferences داخل التطبيق. لا توزّع التطبيق مع مفتاحك ولا تشارك لقطات تكشفه. لتطبيق عام متعدد المستخدمين، انقل طلبات API إلى خادم وسيط مع تسجيل دخول وحدود استخدام. يحتاج التطبيق إنترنت ومفتاحاً صالحاً وقد تكون هناك رسوم من مزود API.

هذا الإصدار يرسل النصوص فقط، ولا يشغّل الأكواد أو ينفّذ أوامر على الجهاز. راجع مخرجات النموذج واختبرها قبل الاستخدام.
